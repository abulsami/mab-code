﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace IUApp
{
    public partial class RegistrationForm : Form
    {
        public RegistrationForm()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            String message = "";

            message += txtFullName.Text + "\n";
            message += txtEmail.Text + "\n";
            message += txtPassword.Text + "\n";

            if (rbMale.Checked)
            {
                message += "Male" + "\n";
            }
            else {
                message += "Female" + "\n";
            }

            message += dobPicker.Value.ToString("dd/MM/yyyy") + "\n";
            message += txtMobile.Text + "\n";

            if (cbPhysicallyChallenged.Checked) {
                message += "IsPhysicallyChallenged" + "\n";
            }

            message += cmbCountry.SelectedItem.ToString() + "\n";
            message += txtStreet.Text + "\n";
            message += lbCity.SelectedItem.ToString();

            MessageBox.Show(message,"Registration Form");

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtFullName.Text = "";
        }

        private void txtEmail_Validating(object sender, CancelEventArgs e)
        {
            Regex rEmail = new Regex(@"\w+(-+.]\w+)*@\w+(-.]\w+)*\.\w+(-.]\w+)*");
            if (txtEmail.Text.Length > 0)
            {
                if (!rEmail.IsMatch(txtEmail.Text))
                {
                    errorProvider1.SetError(txtEmail, "Invalid Email");
                    txtEmail.SelectAll();
                    txtEmail.Focus();
                    e.Cancel = true;
                }
                else
                {
                    errorProvider1.Clear();
                }
            }
        }

        private void txtConfirmPassword_Validating(object sender, CancelEventArgs e)
        {
            if (txtPassword.Text == txtConfirmPassword.Text)
            {
                errorProvider1.Clear();
            }
            else {
                errorProvider1.SetError(txtConfirmPassword, "Passwords donot match!");
                txtEmail.SelectAll();
                txtEmail.Focus();
                e.Cancel = true;
            }
        }

        private void txtFullName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && Convert.ToInt32(e.KeyChar) != 8 && Convert.ToInt32(e.KeyChar) != 32)
            {
                errorProvider1.SetError(txtFullName, "Only letters are allowed!");
            }
            else {
                errorProvider1.Clear();
            }
        }

        private void txtMobile_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && Convert.ToInt32(e.KeyChar) != 8)
            {
                errorProvider1.SetError(txtMobile, "Only numbers are allowed!");
            }
            else {
                errorProvider1.Clear();
            }
        }
    }
}
